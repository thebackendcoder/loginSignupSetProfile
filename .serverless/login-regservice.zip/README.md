# loginSignupSetProfile
This is for Registering and the signup Part
